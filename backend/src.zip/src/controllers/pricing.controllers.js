import { Hotel } from "../models/hotel.models.js";
import { Pricing } from "../models/pricing.models.js";

export const createPricing = async (req, res) => {
  try {
    const {
      name,
      startDate,
      endDate,
      multiplier,
      hotelId,
      specialOfferPercent,
      specialOfferAmount
    } = req.body;
    const hotel = await Hotel.findOne({
      _id: hotelId,
      ownerId: req.user._id
    });

    if (!hotel) {
      return res.status(403).json({
        message: "You are not authorized for this hotel"
      });
    }
    if (new Date(startDate) >= new Date(endDate)) {
      return res.status(400).json({
        message: "End date must be after start date"
      });
    }
    const pricing = await Pricing.create({
      name,
      startDate,
      endDate,
      multiplier,
      hotelId,
      specialOfferPercent,
      specialOfferAmount
    });

    res.status(201).json({
      message: "Pricing rule created successfully",
      pricing
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
export const getHotelPricing = async (req, res) => {
  try {
    const { hotelId } = req.params;
    const hotel = await Hotel.findOne({
      _id: hotelId,
      ownerId: req.user._id
    });

    if (!hotel) {
      return res.status(403).json({
        message: "Unauthorized access"
      });
    }

    const pricing = await Pricing.find({ hotelId })
      .sort({ startDate: 1 });

    res.json(pricing);

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const updatePricing = async (req, res) => {
  try {
    const { pricingId } = req.params;

    const pricing = await Pricing.findById(pricingId);

    if (!pricing) {
      return res.status(404).json({ message: "Pricing not found" });
    }

    const hotel = await Hotel.findOne({
      _id: pricing.hotelId,
      ownerId: req.user._id
    });

    if (!hotel) {
      return res.status(403).json({
        message: "Unauthorized"
      });
    }

    const updated = await Pricing.findByIdAndUpdate(
      pricingId,
      req.body,
      { new: true }
    );

    res.json({
      message: "Pricing updated successfully",
      updated
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const deletePricing = async (req, res) => {
  try {
    const { pricingId } = req.params;

    const pricing = await Pricing.findById(pricingId);

    if (!pricing) {
      return res.status(404).json({ message: "Pricing not found" });
    }
    const hotel = await Hotel.findOne({
      _id: pricing.hotelId,
      ownerId: req.user._id
    });

    if (!hotel) {
      return res.status(403).json({
        message: "Unauthorized"
      });
    }

    await Pricing.findByIdAndDelete(pricingId);

    res.json({
      message: "Pricing deleted successfully"
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};